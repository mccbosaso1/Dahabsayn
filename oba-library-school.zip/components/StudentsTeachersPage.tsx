import React from 'react';
import { PageWrapper } from './PageWrapper';

export const StudentsTeachersPage: React.FC = () => {
  return (
    <PageWrapper title="For Students & Teachers">
      <div className="grid lg:grid-cols-2 gap-12">
        
        {/* For Students Section */}
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-3xl font-serif text-brand-blue mb-6">Student Resources</h2>
          <img src="https://picsum.photos/seed/students/600/400" alt="Students in library" className="rounded-lg mb-6"/>
          <div className="space-y-4 text-gray-700">
            <h3 className="text-xl font-bold text-brand-dark">Reading Programs</h3>
            <p>Join our annual Reading Challenge or sign up for a monthly book club. Earn prizes, meet new friends, and explore exciting new worlds through books!</p>
            <h3 className="text-xl font-bold text-brand-dark">Research Help</h3>
            <p>Struggling with a project? Our librarians are here to help you find reliable sources, cite them correctly, and develop strong research skills. Book a session today.</p>
            <h3 className="text-xl font-bold text-brand-dark">Digital Access</h3>
            <p>Your student ID gives you access to thousands of e-books, audiobooks, and educational videos from anywhere, at any time.</p>
          </div>
        </div>

        {/* For Teachers Section */}
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-3xl font-serif text-brand-blue mb-6">Teacher Resources</h2>
          <img src="https://picsum.photos/seed/teachers/600/400" alt="Teacher with books" className="rounded-lg mb-6"/>
          <div className="space-y-4 text-gray-700">
            <h3 className="text-xl font-bold text-brand-dark">Classroom Collaboration</h3>
            <p>Partner with our librarians to curate book collections for your curriculum, co-teach research lessons, or schedule a library orientation for your classes.</p>
            <h3 className="text-xl font-bold text-brand-dark">Resource Booking</h3>
            <p>Reserve library spaces, mobile laptop carts, or specific resource kits to enhance your classroom instruction.</p>
             <h3 className="text-xl font-bold text-brand-dark">Professional Development</h3>
            <p>We offer a collection of professional development books and resources to support your growth as an educator.</p>
          </div>
        </div>
      </div>
    </PageWrapper>
  );
};
