import React from 'react';

interface PageWrapperProps {
  title: string;
  children: React.ReactNode;
}

export const PageWrapper: React.FC<PageWrapperProps> = ({ title, children }) => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 animate-fadeIn">
      <h1 className="text-4xl md:text-5xl font-serif text-brand-blue mb-8 md:mb-12 text-center">{title}</h1>
      {children}
    </div>
  );
};
