import React from 'react';
import { FEATURED_BOOKS, BLOG_POSTS } from '../constants';

export const HomePage: React.FC = () => {
  return (
    <div className="animate-fadeIn space-y-16">
      {/* Hero Section */}
      <section 
        className="bg-cover bg-center py-20 md:py-32 text-white" 
        style={{backgroundImage: "linear-gradient(rgba(30, 58, 138, 0.8), rgba(30, 58, 138, 0.8)), url('https://picsum.photos/seed/librarybg/1600/600')"}}
      >
        <div className="container mx-auto text-center px-4">
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-4">Welcome to OBA Library</h1>
          <p className="text-lg md:text-xl max-w-3xl mx-auto">Discover a world of knowledge, adventure, and inspiration. Your journey begins here.</p>
        </div>
      </section>

      {/* Featured Books Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-serif text-brand-blue mb-8 text-center">Featured Books</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          {FEATURED_BOOKS.map(book => (
            <div key={book.id} className="text-center group">
              <img 
                src={book.coverUrl} 
                alt={book.title} 
                className="w-full h-auto object-cover rounded-lg shadow-lg mb-4 transform group-hover:-translate-y-2 transition-transform duration-300" 
              />
              <h3 className="font-bold text-lg text-brand-dark">{book.title}</h3>
              <p className="text-sm text-gray-600">{book.author}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Recent Posts Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-serif text-brand-blue mb-8 text-center">Recent News & Updates</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {BLOG_POSTS.slice(0, 3).map(post => (
              <div key={post.id} className="border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-300">
                <img src={post.imageUrl} alt={post.title} className="w-full h-48 object-cover"/>
                <div className="p-6">
                  <p className="text-sm text-gray-500 mb-2">{post.date}</p>
                  <h3 className="text-xl font-bold text-brand-blue mb-2">{post.title}</h3>
                  <p className="text-gray-700">{post.excerpt}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
