import React from 'react';
import { PageWrapper } from './PageWrapper';

export const AboutPage: React.FC = () => {
  return (
    <PageWrapper title="About OBA Library">
      <div className="max-w-4xl mx-auto space-y-12 text-lg text-gray-700 leading-relaxed">
        
        <section className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-3xl font-serif text-brand-blue mb-4">Our Mission</h2>
          <p>
            The mission of the OBA Library School is to foster a lifelong love of reading and learning. We are dedicated to providing a welcoming, inclusive, and resource-rich environment that supports the academic curriculum, empowers students to become critical thinkers, and inspires intellectual curiosity within our entire school community.
          </p>
        </section>

        <section className="grid md:grid-cols-2 gap-8 items-center">
          <img src="https://picsum.photos/seed/abouthistory/600/400" alt="Library history" className="rounded-lg shadow-lg"/>
          <div>
            <h2 className="text-3xl font-serif text-brand-blue mb-4">Our History</h2>
            <p>
              Founded in 1985, the OBA Library has grown from a small collection of donated books to a vibrant, modern learning commons. Throughout the years, we have adapted to the changing needs of education, embracing technology and innovative learning methods while preserving the timeless value of books.
            </p>
          </div>
        </section>
        
        <section className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-3xl font-serif text-brand-blue mb-4">Services We Offer</h2>
          <ul className="list-disc list-inside space-y-3 pl-4">
            <li>A diverse collection of over 20,000 fiction and non-fiction books.</li>
            <li>Access to online academic databases, e-books, and digital journals.</li>
            <li>Quiet study areas, collaborative workspaces, and reading nooks.</li>
            <li>Computer workstations with internet access and printing services.</li>
            <li>Research assistance and information literacy instruction from our dedicated librarians.</li>
            <li>Engaging reading programs, author visits, and book clubs throughout the year.</li>
          </ul>
        </section>
        
      </div>
    </PageWrapper>
  );
};
