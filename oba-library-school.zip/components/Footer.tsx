import React from 'react';
import type { Page } from '../types';
import { NAV_LINKS } from '../constants';
import { BookOpenIcon } from './icons/BookOpenIcon';
import { FacebookIcon, TwitterIcon, InstagramIcon } from './icons/SocialIcons';

interface FooterProps {
  setCurrentPage: (page: Page) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  return (
    <footer className="bg-brand-dark text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <BookOpenIcon className="h-8 w-8 text-brand-gold" />
              <span className="text-2xl font-serif font-bold">OBA Library School</span>
            </div>
            <p className="text-slate-300">Your gateway to knowledge and imagination. &copy; {new Date().getFullYear()}</p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-300 hover:text-brand-gold transition-colors"><FacebookIcon className="h-6 w-6" /></a>
              <a href="#" className="text-slate-300 hover:text-brand-gold transition-colors"><TwitterIcon className="h-6 w-6" /></a>
              <a href="#" className="text-slate-300 hover:text-brand-gold transition-colors"><InstagramIcon className="h-6 w-6" /></a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-brand-gold uppercase tracking-wider">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              {NAV_LINKS.map(link => (
                <li key={link.page}>
                  <a
                    href="#"
                    onClick={(e) => { e.preventDefault(); setCurrentPage(link.page); }}
                    className="text-slate-300 hover:text-white transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-brand-gold uppercase tracking-wider">Contact Us</h3>
            <address className="mt-4 not-italic text-slate-300 space-y-2">
              <p>Backside of Hotel Karama 2, Bosaso Puntland Somalia</p>
              <p>Email: <a href="mailto:omarbinabdilazizschool1997@gmail.com" className="hover:text-white">omarbinabdilazizschool1997@gmail.com</a></p>
              <p>Phone: +252907669001</p>
            </address>
          </div>
          
        </div>
      </div>
    </footer>
  );
};