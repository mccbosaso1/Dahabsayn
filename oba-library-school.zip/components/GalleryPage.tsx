import React, { useState, useEffect } from 'react';
import { PageWrapper } from './PageWrapper';
import { GALLERY_IMAGES } from '../constants';
import { ChevronLeftIcon } from './icons/ChevronLeftIcon';
import { ChevronRightIcon } from './icons/ChevronRightIcon';
import { XIcon } from './icons/XIcon';

export const GalleryPage: React.FC = () => {
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);

  const handleOpenLightbox = (index: number) => {
    setSelectedImageIndex(index);
  };

  const handleCloseLightbox = () => {
    setSelectedImageIndex(null);
  };

  const handleNextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex((selectedImageIndex + 1) % GALLERY_IMAGES.length);
    }
  };

  const handlePrevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex((selectedImageIndex - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseLightbox();
      }
      if(selectedImageIndex !== null) {
        if (e.key === 'ArrowRight') {
            setSelectedImageIndex((prevIndex) => (prevIndex! + 1) % GALLERY_IMAGES.length);
        }
        if (e.key === 'ArrowLeft') {
            setSelectedImageIndex((prevIndex) => (prevIndex! - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [selectedImageIndex]);

  return (
    <PageWrapper title="Our Library in Pictures">
      <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
        {GALLERY_IMAGES.map((image, index) => (
          <div 
            key={image.id} 
            className="overflow-hidden rounded-lg shadow-lg break-inside-avoid relative group cursor-pointer"
            onClick={() => handleOpenLightbox(index)}
          >
            <img
              src={image.src}
              alt={image.alt}
              className="w-full h-auto object-cover transform transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-end">
                <p className="text-white p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-sm">{image.alt}</p>
            </div>
          </div>
        ))}
      </div>

      {selectedImageIndex !== null && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4 animate-fadeIn"
          onClick={handleCloseLightbox}
        >
          <button 
            className="absolute top-4 right-4 text-white hover:text-brand-gold transition-colors z-[60]"
            onClick={handleCloseLightbox}
            aria-label="Close image viewer"
          >
            <XIcon className="h-8 w-8" />
          </button>
          
          <button 
            className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 text-white bg-black bg-opacity-30 p-2 rounded-full hover:bg-opacity-50 transition-colors z-[60]"
            onClick={handlePrevImage}
            aria-label="Previous image"
          >
            <ChevronLeftIcon className="h-8 w-8" />
          </button>

          <button 
            className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 text-white bg-black bg-opacity-30 p-2 rounded-full hover:bg-opacity-50 transition-colors z-[60]"
            onClick={handleNextImage}
            aria-label="Next image"
          >
            <ChevronRightIcon className="h-8 w-8" />
          </button>

          <div 
            className="relative max-w-full max-h-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img 
              src={GALLERY_IMAGES[selectedImageIndex].src} 
              alt={GALLERY_IMAGES[selectedImageIndex].alt}
              className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl"
            />
            <p className="text-white text-center mt-4 text-lg">{GALLERY_IMAGES[selectedImageIndex].alt}</p>
          </div>
        </div>
      )}
    </PageWrapper>
  );
};
