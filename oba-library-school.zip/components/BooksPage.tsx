import React from 'react';
import { PageWrapper } from './PageWrapper';
import { BOOK_CATEGORIES } from '../constants';

export const BooksPage: React.FC = () => {
  return (
    <PageWrapper title="Explore Our Collection">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6 md:gap-8">
        {BOOK_CATEGORIES.map(category => (
          <div key={category.name} className="relative rounded-lg overflow-hidden group shadow-lg hover:shadow-2xl transition-shadow duration-300">
            <img 
              src={category.coverUrl} 
              alt={category.name} 
              className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-60 transition-all duration-300 flex items-center justify-center">
              <h3 className="text-white text-2xl font-bold font-serif text-center p-4">{category.name}</h3>
            </div>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
};
