import React from 'react';
import { PageWrapper } from './PageWrapper';

export const ContactPage: React.FC = () => {
  return (
    <PageWrapper title="Get In Touch">
      <div className="grid lg:grid-cols-2 gap-12">
        
        {/* Contact Form */}
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold text-brand-dark mb-6">Send us a Message</h2>
          <form className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
              <input type="text" id="name" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue sm:text-sm" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
              <input type="email" id="email" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue sm:text-sm" />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
              <textarea id="message" rows={4} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue sm:text-sm"></textarea>
            </div>
            <div>
              <button type="submit" className="w-full py-3 px-4 bg-brand-blue text-white font-semibold rounded-md shadow-sm hover:bg-brand-blue/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-blue transition-colors">
                Submit
              </button>
            </div>
          </form>
        </div>

        {/* Contact Info & Map */}
        <div className="space-y-8">
          <div className="bg-white p-8 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold text-brand-dark mb-4">Our Location</h2>
            <address className="not-italic text-gray-700 space-y-2">
              <p><strong>OBA Library School</strong></p>
              <p>Backside of Hotel Karama 2</p>
              <p>Bosaso, Puntland, Somalia</p>
              <p><strong>Email:</strong> <a href="mailto:omarbinabdilazizschool1997@gmail.com" className="text-brand-blue hover:underline">omarbinabdilazizschool1997@gmail.com</a></p>
              <p><strong>Phone:</strong> +252907669001</p>
            </address>
          </div>
          <div className="rounded-lg overflow-hidden shadow-md">
            <img src="https://picsum.photos/seed/map/800/600" alt="Map to the library" className="w-full h-auto object-cover"/>
          </div>
        </div>

      </div>
    </PageWrapper>
  );
};