import React from 'react';
import { PageWrapper } from './PageWrapper';
import { BLOG_POSTS } from '../constants';

export const BlogPage: React.FC = () => {
  return (
    <PageWrapper title="Library News & Blog">
      <div className="max-w-4xl mx-auto space-y-12">
        {BLOG_POSTS.map(post => (
          <div key={post.id} className="grid md:grid-cols-3 gap-8 items-center bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
            <div className="md:col-span-1">
              <img src={post.imageUrl} alt={post.title} className="w-full h-auto object-cover rounded-lg"/>
            </div>
            <div className="md:col-span-2">
              <p className="text-sm text-gray-500 mb-2">{post.date}</p>
              <h2 className="text-2xl font-bold font-serif text-brand-blue mb-3">{post.title}</h2>
              <p className="text-gray-700 leading-relaxed">{post.excerpt}</p>
              <a href="#" className="text-brand-blue font-semibold mt-4 inline-block hover:underline">Read More &rarr;</a>
            </div>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
};
