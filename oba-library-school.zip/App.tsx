import React, { useState } from 'react';
import type { Page } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './components/HomePage';
import { AboutPage } from './components/AboutPage';
import { BooksPage } from './components/BooksPage';
import { StudentsTeachersPage } from './components/StudentsTeachersPage';
import { GalleryPage } from './components/GalleryPage';
import { BlogPage } from './components/BlogPage';
import { ContactPage } from './components/ContactPage';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'about':
        return <AboutPage />;
      case 'books':
        return <BooksPage />;
      case 'students':
        return <StudentsTeachersPage />;
      case 'gallery':
        return <GalleryPage />;
      case 'blog':
        return <BlogPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-brand-light">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <div className="flex-grow">
        {renderPage()}
      </div>
      <Footer setCurrentPage={setCurrentPage} />
    </div>
  );
};

export default App;
