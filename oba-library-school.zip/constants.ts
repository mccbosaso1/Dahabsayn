import type { NavLink, Book, BookCategory, Post, GalleryImage } from './types';

export const NAV_LINKS: NavLink[] = [
  { name: 'Home', page: 'home' },
  { name: 'About', page: 'about' },
  { name: 'Books', page: 'books' },
  { name: 'Students & Teachers', page: 'students' },
  { name: 'Gallery', page: 'gallery' },
  { name: 'Blog', page: 'blog' },
  { name: 'Contact', page: 'contact' },
];

export const FEATURED_BOOKS: Book[] = [
  { id: 1, title: 'The Quantum World', author: 'Dr. Evelyn Reed', coverUrl: 'https://picsum.photos/seed/book1/300/400' },
  { id: 2, title: 'Echoes of Antiquity', author: 'Marcus Stone', coverUrl: 'https://picsum.photos/seed/book2/300/400' },
  { id: 3, title: 'Literary Giants', author: 'Helena Paige', coverUrl: 'https://picsum.photos/seed/book3/300/400' },
  { id: 4, title: 'Code Breakers', author: 'Alan Vector', coverUrl: 'https://picsum.photos/seed/book4/300/400' },
];

export const BOOK_CATEGORIES: BookCategory[] = [
    { name: 'Science', coverUrl: 'https://picsum.photos/seed/science/400/500' },
    { name: 'Literature', coverUrl: 'https://picsum.photos/seed/literature/400/500' },
    { name: 'History', coverUrl: 'https://picsum.photos/seed/history/400/500' },
    { name: 'Technology', coverUrl: 'https://picsum.photos/seed/tech/400/500' },
    { name: 'Arts & Music', coverUrl: 'https://picsum.photos/seed/arts/400/500' },
    { name: 'Biographies', coverUrl: 'https://picsum.photos/seed/bio/400/500' },
    { name: 'Fantasy', coverUrl: 'https://picsum.photos/seed/fantasy/400/500' },
    { name: 'Health & Wellness', coverUrl: 'https://picsum.photos/seed/health/400/500' },
];

export const BLOG_POSTS: Post[] = [
  { id: 1, title: 'Welcome to the New School Year!', date: 'September 1, 2024', excerpt: 'A warm welcome to all new and returning students. Here\'s what\'s new at the OBA Library this year...', imageUrl: 'https://picsum.photos/seed/blog1/600/400' },
  { id: 2, title: 'How to Research Effectively', date: 'September 15, 2024', excerpt: 'Unlock the secrets to powerful research with our top tips and tricks for navigating databases and sources.', imageUrl: 'https://picsum.photos/seed/blog2/600/400' },
  { id: 3, title: 'Author of the Month: Jane Austen', date: 'October 5, 2024', excerpt: 'This month, we celebrate the timeless works of Jane Austen. Discover her novels on our featured shelf.', imageUrl: 'https://picsum.photos/seed/blog3/600/400' },
  { id: 4, title: 'New Digital Resources Available', date: 'October 20, 2024', excerpt: 'Explore our newly added collection of e-books and academic journals, now available to all students.', imageUrl: 'https://picsum.photos/seed/blog4/600/400' },
];

export const GALLERY_IMAGES: GalleryImage[] = [
    { id: 1, src: 'https://picsum.photos/seed/gallery1/600/800', alt: 'Bright and airy study area with large windows' },
    { id: 2, src: 'https://picsum.photos/seed/gallery2/800/600', alt: 'Close-up of a bookshelf filled with classic literature' },
    { id: 3, src: 'https://picsum.photos/seed/gallery3/600/600', alt: 'Students collaborating at a large table' },
    { id: 4, src: 'https://picsum.photos/seed/gallery4/800/600', alt: 'The main library circulation desk' },
    { id: 5, src: 'https://picsum.photos/seed/gallery5/600/800', alt: 'A cozy reading nook with a comfortable armchair' },
    { id: 6, src: 'https://picsum.photos/seed/gallery6/600/600', alt: 'Library exterior on a sunny day' },
    { id: 7, src: 'https://picsum.photos/seed/gallery7/600/800', alt: 'A student using a library computer for research' },
    { id: 8, src: 'https://picsum.photos/seed/gallery8/800/600', alt: 'Shelves of modern technology and science books' },
];
