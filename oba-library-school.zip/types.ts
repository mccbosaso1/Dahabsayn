export type Page = 'home' | 'about' | 'books' | 'students' | 'gallery' | 'blog' | 'contact';

export interface NavLink {
  name: string;
  page: Page;
}

export interface Book {
  id: number;
  title: string;
  author: string;
  coverUrl: string;
}

export interface BookCategory {
  name:string;
  coverUrl: string;
}

export interface Post {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  imageUrl: string;
}

export interface GalleryImage {
  id: number;
  src: string;
  alt: string;
}
